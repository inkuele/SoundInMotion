65538
1
325
324
0
0
1
1
0
325
325
962
60
r
1.4013e-45
0
{
   rate = 60
   start = 325
   tracklength = 1
   tracks = 1
   {
      name = r
      data_rle = 0 
   }

}
