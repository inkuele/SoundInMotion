65538
1
325
324
0
0
1
1
0
325
325
0
60
pos
{
   rate = 60
   start = 325
   tracklength = 1
   tracks = 1
   {
      name = pos
      data_rle = 0.5 
   }

}
