65538
99
325
324
0
0
1
1
0
325
325
0
60
frame
timestamp
p1/id
p1/pelvis:tx
p1/pelvis:ty
p1/pelvis:tz
p1/spine_navel:tx
p1/spine_navel:ty
p1/spine_navel:tz
p1/spine_chest:tx
p1/spine_chest:ty
p1/spine_chest:tz
p1/neck:tx
p1/neck:ty
p1/neck:tz
p1/clavicle_l:tx
p1/clavicle_l:ty
p1/clavicle_l:tz
p1/shoulder_l:tx
p1/shoulder_l:ty
p1/shoulder_l:tz
p1/elbow_l:tx
p1/elbow_l:ty
p1/elbow_l:tz
p1/wrist_l:tx
p1/wrist_l:ty
p1/wrist_l:tz
p1/hand_l:tx
p1/hand_l:ty
p1/hand_l:tz
p1/handtip_l:tx
p1/handtip_l:ty
p1/handtip_l:tz
p1/thumb_l:tx
p1/thumb_l:ty
p1/thumb_l:tz
p1/clavicle_r:tx
p1/clavicle_r:ty
p1/clavicle_r:tz
p1/shoulder_r:tx
p1/shoulder_r:ty
p1/shoulder_r:tz
p1/elbow_r:tx
p1/elbow_r:ty
p1/elbow_r:tz
p1/wrist_r:tx
p1/wrist_r:ty
p1/wrist_r:tz
p1/hand_r:tx
p1/hand_r:ty
p1/hand_r:tz
p1/handtip_r:tx
p1/handtip_r:ty
p1/handtip_r:tz
p1/thumb_r:tx
p1/thumb_r:ty
p1/thumb_r:tz
p1/hip_l:tx
p1/hip_l:ty
p1/hip_l:tz
p1/knee_l:tx
p1/knee_l:ty
p1/knee_l:tz
p1/ankle_l:tx
p1/ankle_l:ty
p1/ankle_l:tz
p1/foot_l:tx
p1/foot_l:ty
p1/foot_l:tz
p1/hip_r:tx
p1/hip_r:ty
p1/hip_r:tz
p1/knee_r:tx
p1/knee_r:ty
p1/knee_r:tz
p1/ankle_r:tx
p1/ankle_r:ty
p1/ankle_r:tz
p1/foot_r:tx
p1/foot_r:ty
p1/foot_r:tz
p1/head:tx
p1/head:ty
p1/head:tz
p1/nose:tx
p1/nose:ty
p1/nose:tz
p1/eye_l:tx
p1/eye_l:ty
p1/eye_l:tz
p1/ear_l:tx
p1/ear_l:ty
p1/ear_l:tz
p1/eye_r:tx
p1/eye_r:ty
p1/eye_r:tz
p1/ear_r:tx
p1/ear_r:ty
p1/ear_r:tz
{
   rate = 60
   start = 325
   tracklength = 1
   tracks = 99
   {
      name = frame
      data_rle = 2537 
   }
   {
      name = timestamp
      data_rle = 0 
   }
   {
      name = p1/id
      data_rle = 0 
   }
   {
      name = p1/pelvis:tx
      data_rle = 0 
   }
   {
      name = p1/pelvis:ty
      data_rle = 0 
   }
   {
      name = p1/pelvis:tz
      data_rle = 0 
   }
   {
      name = p1/spine_navel:tx
      data_rle = 0 
   }
   {
      name = p1/spine_navel:ty
      data_rle = 0 
   }
   {
      name = p1/spine_navel:tz
      data_rle = 0 
   }
   {
      name = p1/spine_chest:tx
      data_rle = 0 
   }
   {
      name = p1/spine_chest:ty
      data_rle = 0 
   }
   {
      name = p1/spine_chest:tz
      data_rle = 0 
   }
   {
      name = p1/neck:tx
      data_rle = 0 
   }
   {
      name = p1/neck:ty
      data_rle = 0 
   }
   {
      name = p1/neck:tz
      data_rle = 0 
   }
   {
      name = p1/clavicle_l:tx
      data_rle = 0 
   }
   {
      name = p1/clavicle_l:ty
      data_rle = 0 
   }
   {
      name = p1/clavicle_l:tz
      data_rle = 0 
   }
   {
      name = p1/shoulder_l:tx
      data_rle = 0 
   }
   {
      name = p1/shoulder_l:ty
      data_rle = 0 
   }
   {
      name = p1/shoulder_l:tz
      data_rle = 0 
   }
   {
      name = p1/elbow_l:tx
      data_rle = 0 
   }
   {
      name = p1/elbow_l:ty
      data_rle = 0 
   }
   {
      name = p1/elbow_l:tz
      data_rle = 0 
   }
   {
      name = p1/wrist_l:tx
      data_rle = 0 
   }
   {
      name = p1/wrist_l:ty
      data_rle = 0 
   }
   {
      name = p1/wrist_l:tz
      data_rle = 0 
   }
   {
      name = p1/hand_l:tx
      data_rle = 0 
   }
   {
      name = p1/hand_l:ty
      data_rle = 0 
   }
   {
      name = p1/hand_l:tz
      data_rle = 0 
   }
   {
      name = p1/handtip_l:tx
      data_rle = 0 
   }
   {
      name = p1/handtip_l:ty
      data_rle = 0 
   }
   {
      name = p1/handtip_l:tz
      data_rle = 0 
   }
   {
      name = p1/thumb_l:tx
      data_rle = 0 
   }
   {
      name = p1/thumb_l:ty
      data_rle = 0 
   }
   {
      name = p1/thumb_l:tz
      data_rle = 0 
   }
   {
      name = p1/clavicle_r:tx
      data_rle = 0 
   }
   {
      name = p1/clavicle_r:ty
      data_rle = 0 
   }
   {
      name = p1/clavicle_r:tz
      data_rle = 0 
   }
   {
      name = p1/shoulder_r:tx
      data_rle = 0 
   }
   {
      name = p1/shoulder_r:ty
      data_rle = 0 
   }
   {
      name = p1/shoulder_r:tz
      data_rle = 0 
   }
   {
      name = p1/elbow_r:tx
      data_rle = 0 
   }
   {
      name = p1/elbow_r:ty
      data_rle = 0 
   }
   {
      name = p1/elbow_r:tz
      data_rle = 0 
   }
   {
      name = p1/wrist_r:tx
      data_rle = 0 
   }
   {
      name = p1/wrist_r:ty
      data_rle = 0 
   }
   {
      name = p1/wrist_r:tz
      data_rle = 0 
   }
   {
      name = p1/hand_r:tx
      data_rle = 0 
   }
   {
      name = p1/hand_r:ty
      data_rle = 0 
   }
   {
      name = p1/hand_r:tz
      data_rle = 0 
   }
   {
      name = p1/handtip_r:tx
      data_rle = 0 
   }
   {
      name = p1/handtip_r:ty
      data_rle = 0 
   }
   {
      name = p1/handtip_r:tz
      data_rle = 0 
   }
   {
      name = p1/thumb_r:tx
      data_rle = 0 
   }
   {
      name = p1/thumb_r:ty
      data_rle = 0 
   }
   {
      name = p1/thumb_r:tz
      data_rle = 0 
   }
   {
      name = p1/hip_l:tx
      data_rle = 0 
   }
   {
      name = p1/hip_l:ty
      data_rle = 0 
   }
   {
      name = p1/hip_l:tz
      data_rle = 0 
   }
   {
      name = p1/knee_l:tx
      data_rle = 0 
   }
   {
      name = p1/knee_l:ty
      data_rle = 0 
   }
   {
      name = p1/knee_l:tz
      data_rle = 0 
   }
   {
      name = p1/ankle_l:tx
      data_rle = 0 
   }
   {
      name = p1/ankle_l:ty
      data_rle = 0 
   }
   {
      name = p1/ankle_l:tz
      data_rle = 0 
   }
   {
      name = p1/foot_l:tx
      data_rle = 0 
   }
   {
      name = p1/foot_l:ty
      data_rle = 0 
   }
   {
      name = p1/foot_l:tz
      data_rle = 0 
   }
   {
      name = p1/hip_r:tx
      data_rle = 0 
   }
   {
      name = p1/hip_r:ty
      data_rle = 0 
   }
   {
      name = p1/hip_r:tz
      data_rle = 0 
   }
   {
      name = p1/knee_r:tx
      data_rle = 0 
   }
   {
      name = p1/knee_r:ty
      data_rle = 0 
   }
   {
      name = p1/knee_r:tz
      data_rle = 0 
   }
   {
      name = p1/ankle_r:tx
      data_rle = 0 
   }
   {
      name = p1/ankle_r:ty
      data_rle = 0 
   }
   {
      name = p1/ankle_r:tz
      data_rle = 0 
   }
   {
      name = p1/foot_r:tx
      data_rle = 0 
   }
   {
      name = p1/foot_r:ty
      data_rle = 0 
   }
   {
      name = p1/foot_r:tz
      data_rle = 0 
   }
   {
      name = p1/head:tx
      data_rle = 0 
   }
   {
      name = p1/head:ty
      data_rle = 0 
   }
   {
      name = p1/head:tz
      data_rle = 0 
   }
   {
      name = p1/nose:tx
      data_rle = 0 
   }
   {
      name = p1/nose:ty
      data_rle = 0 
   }
   {
      name = p1/nose:tz
      data_rle = 0 
   }
   {
      name = p1/eye_l:tx
      data_rle = 0 
   }
   {
      name = p1/eye_l:ty
      data_rle = 0 
   }
   {
      name = p1/eye_l:tz
      data_rle = 0 
   }
   {
      name = p1/ear_l:tx
      data_rle = 0 
   }
   {
      name = p1/ear_l:ty
      data_rle = 0 
   }
   {
      name = p1/ear_l:tz
      data_rle = 0 
   }
   {
      name = p1/eye_r:tx
      data_rle = 0 
   }
   {
      name = p1/eye_r:ty
      data_rle = 0 
   }
   {
      name = p1/eye_r:tz
      data_rle = 0 
   }
   {
      name = p1/ear_r:tx
      data_rle = 0 
   }
   {
      name = p1/ear_r:ty
      data_rle = 0 
   }
   {
      name = p1/ear_r:tz
      data_rle = 0 
   }

}
