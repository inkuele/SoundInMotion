65538
1
325
324
0
0
1
1
0
325
325
5062
60
p1/head:tx
0.5
0
{
   rate = 60
   start = 325
   tracklength = 1
   tracks = 1
   {
      name = p1/head:tx
      data_rle = 0.5 
   }

}
